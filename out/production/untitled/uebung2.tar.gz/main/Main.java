package main;

import static matrix.MatrixTools.*;

public class Main
{
    public static void main(String[] args)
    {

        if (matrixMul(createMatrix(2,3), createMatrix(3,4)) == null)
        {
            System.out.println("amk praktomat du bist ein otto");
        }
    }
}
